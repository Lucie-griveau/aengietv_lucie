Where to find what:

plugin/
	The script itself

demo/
	Demonstration of including, invoking, etc.

thirdparty/
	Other libraries
